<?php 
include_once('sidebar.php');
include_once('conn.php');?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Show Contact Us List</h1>
       </div>
       <div class="table-responsive">
        <table class="table table-border">
          <tr>
            <th>contactid</th>
            <th>fname</th>
            <th>lname</th>
            <th>Emailid</th>
            <th>Mobile</th>
            <th>Message</th>
            <th>datetime</th>
            
          </tr>
          <?php
          $query="select* from listtbl";
          $result=mysqli_query($con,$query);
          while($row=mysqli_fetch_assoc($result)){ ?>
          
        <td><?php echo $row['id'];?></td>    
        <td><?php echo $row['fname'];?></td>
        <td><?php echo $row['lname'];?></td>
        <td><?php echo $row['emailid'];?></td>
        <td><?php echo $row['mobile'];?></td>
        <td><?php echo $row['message'];?></td> 
        <td><?php echo $row['insertdatetime'];?></td>
          </tr>
        <?php
      } ?>
        </table>
      </div>
    </main>

